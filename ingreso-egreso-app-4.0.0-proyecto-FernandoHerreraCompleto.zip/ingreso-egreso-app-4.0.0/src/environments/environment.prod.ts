export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyBxK6eNwHoAKYBGDW3cUlhLaGytNIOiWcs',
    authDomain: 'ingreso-egreso-app.firebaseapp.com',
    databaseURL: 'https://ingreso-egreso-app.firebaseio.com',
    projectId: 'ingreso-egreso-app',
    storageBucket: 'ingreso-egreso-app.appspot.com',
    messagingSenderId: '577324738477'
  }
};
